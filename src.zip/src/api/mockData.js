export const bars = [
  { id: 1, name: "Club Infinity", location: "District 1" },
  { id: 2, name: "SkyBar", location: "District 3" },
];

export const performers = [
  { id: 1, name: "DJ Khoa", type: "DJ" },
  { id: 2, name: "Anna", type: "Dancer" },
];
