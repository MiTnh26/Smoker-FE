export { default as BarDashboard } from "./pages/Dashboard";
export { default as ManageTables } from "./pages/ManageTables";
export { default as ManageEvents } from "./pages/ManageEvents";
