export { default as DJDashboard } from "./pages/Dashboard";
export { default as DJSchedule } from "./pages/Schedule";
export { default as DJProfile } from "./pages/Profile";
